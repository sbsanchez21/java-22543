package com.codoACodo.codoACodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodoACodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
