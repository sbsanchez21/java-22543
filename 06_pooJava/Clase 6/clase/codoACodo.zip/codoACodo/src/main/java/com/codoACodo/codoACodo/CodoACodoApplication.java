package com.codoACodo.codoACodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodoACodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodoACodoApplication.class, args);
	}

}
